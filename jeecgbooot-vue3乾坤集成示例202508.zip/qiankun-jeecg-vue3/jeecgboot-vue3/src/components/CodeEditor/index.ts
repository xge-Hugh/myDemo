import { withInstall } from '/@/utils';
import codeEditor from './src/CodeEditor.vue';

export const CodeEditor = withInstall(codeEditor);
