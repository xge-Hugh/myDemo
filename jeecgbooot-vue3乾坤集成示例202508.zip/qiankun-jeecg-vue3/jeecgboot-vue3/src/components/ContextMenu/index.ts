export { createContextMenu, destroyContextMenu } from './src/createContextMenu';

export * from './src/typing';
