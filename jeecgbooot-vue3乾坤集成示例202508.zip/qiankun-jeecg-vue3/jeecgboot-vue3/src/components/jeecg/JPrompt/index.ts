export { useJPrompt } from './hooks/useJPrompt';
export { default as JPrompt } from './JPrompt.vue';
