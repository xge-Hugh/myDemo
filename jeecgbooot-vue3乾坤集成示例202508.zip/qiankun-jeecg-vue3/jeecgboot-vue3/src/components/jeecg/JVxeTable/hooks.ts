export { useJVxeCompProps, useJVxeComponent } from './src/hooks/useJVxeComponent';
export { useResolveComponent } from './src/hooks/useData';
